### Bonus
#### 1
When some methods are already implemented in the super class. E.g. toString is implemented in the abstract class, so the inheriting classes don't need to implement it.
#### 2 
In difference to interface an abstract class can contain already implemented methods, instead to interface, which can only contain abstract methods.
