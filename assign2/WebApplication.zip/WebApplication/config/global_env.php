<?php 
$GLOBALS["webAddress"] = "http://localhost";
$GLOBALS["indexFile"] = "router.php";
?>